-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2015 at 09:19 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(11) NOT NULL,
  `admin_name` varchar(60) NOT NULL,
  `admin_family` varchar(60) NOT NULL,
  `admin_username` varchar(50) NOT NULL,
  `admin_password` varchar(120) NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `admin_mobile` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
`id` int(11) NOT NULL,
  `brand_name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `brand_picture_name` varchar(180) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_picture_name`) VALUES
(1, 'Addidas', NULL),
(2, 'Nike', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
`id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `address` varchar(400) COLLATE utf8_persian_ci DEFAULT NULL,
  `category_name` varchar(120) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `address`, `category_name`) VALUES
(1, NULL, '1', 'مردانه'),
(2, NULL, '2', 'زنانه'),
(3, 1, '1/3', 'پیراهن'),
(4, 1, '1/4', 'شلوار'),
(5, 1, '1/5', 'تیشرت'),
(6, 2, '2/6', 'پیراهن و شومیز'),
(7, 2, '2/7', 'شلوار'),
(8, 2, '2/8', 'لباس مجلسی');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
`id` int(5) NOT NULL,
  `country_code` char(2) NOT NULL DEFAULT '',
  `country_name` varchar(45) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=251 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES
(205, 'SN', 'Senegal'),
(208, 'SS', 'South Sudan'),
(218, 'TH', 'Thailand'),
(219, 'TJ', 'Tajikistan'),
(223, 'TN', 'Tunisia'),
(233, 'US', 'United States'),
(241, 'VN', 'Vietnam'),
(245, 'XK', 'Kosovo'),
(246, 'YE', 'Yemen');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
`id` int(11) NOT NULL,
  `customer_name` varchar(60) NOT NULL,
  `customer_family` varchar(60) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_password` varchar(120) NOT NULL,
  `customer_active` tinyint(1) NOT NULL DEFAULT '1',
  `customer_gender` enum('0','1') NOT NULL COMMENT '1=>male,0=>female',
  `customer_mobile` varchar(11) DEFAULT NULL,
  `customer_city` varchar(100) DEFAULT NULL,
  `customer_state` varchar(100) DEFAULT NULL,
  `customer_zipcode` int(11) DEFAULT NULL,
  `customer_emergency_number` int(11) DEFAULT NULL,
  `customer_address` text NOT NULL,
  `customer_register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `customer_name`, `customer_family`, `customer_email`, `customer_password`, `customer_active`, `customer_gender`, `customer_mobile`, `customer_city`, `customer_state`, `customer_zipcode`, `customer_emergency_number`, `customer_address`, `customer_register_date`) VALUES
(1, 'soheil', 'saghian', 's@a.com', '123', 1, '1', '09128042106', NULL, NULL, NULL, NULL, 'a', '2015-05-24 18:43:02'),
(4, 'سهیل', 'ساقیان', 'soheilsaghian@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 1, '1', '09128042106', 'تهران', 'شهریار', 1414656663, 21, 'شهریار، جاده ...', '2015-05-30 13:40:50'),
(8, 'a', 'aa', 'info@khorshidfard.ir', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 1, '', '09128042106', NULL, NULL, NULL, NULL, '', '2015-06-01 07:11:44');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
`id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order_subtotal` int(11) NOT NULL DEFAULT '0',
  `order_discount` int(11) NOT NULL DEFAULT '0',
  `order_tax` int(11) NOT NULL DEFAULT '0',
  `order_address` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `order_date`, `order_subtotal`, `order_discount`, `order_tax`, `order_address`) VALUES
(8, 1, '2015-05-23 08:40:09', 1500, 0, 0, 'Noaddress'),
(13, 1, '2015-05-23 13:19:05', 10000, 0, 0, 'Noaddress'),
(14, 1, '2015-05-23 13:28:38', 1500, 0, 0, 'Noaddress'),
(15, 1, '2015-05-24 08:32:21', 13000, 0, 0, 'Noaddress'),
(16, 1, '2015-05-26 07:23:37', 1500, 0, 0, 'Noaddress'),
(17, 1, '2015-05-28 04:05:11', 1500, 0, 0, 'Noaddress'),
(18, 1, '2015-05-28 04:09:21', 5000, 0, 0, 'Noaddress'),
(19, 1, '2015-05-28 04:09:51', 8000, 0, 0, 'Noaddress'),
(20, 1, '2015-05-28 04:10:09', 2000, 0, 0, 'Noaddress'),
(21, 1, '2015-05-28 04:28:49', 2000, 0, 0, 'Noaddress'),
(22, 1, '2015-05-28 04:29:23', 13000, 0, 0, 'Noaddress'),
(23, 1, '2015-05-30 15:54:07', 7000, 0, 0, 'Noaddress'),
(24, 1, '2015-06-01 04:47:11', 5000, 0, 0, 'Noaddress');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE IF NOT EXISTS `order_detail` (
`id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_count` int(11) NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_discount` int(11) NOT NULL DEFAULT '0',
  `product_tax` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `order_id`, `product_id`, `product_count`, `product_price`, `product_discount`, `product_tax`) VALUES
(1, 13, 2, 2, 5000, 0, 0),
(2, 14, 1, 1, 1500, 0, 0),
(3, 15, 1, 2, 1500, 0, 0),
(4, 15, 2, 2, 5000, 0, 0),
(5, 16, 1, 1, 1500, 0, 0),
(6, 17, 1, 1, 1500, 0, 0),
(7, 18, 2, 1, 5000, 0, 0),
(8, 19, 4, 1, 8000, 0, 0),
(9, 20, 9, 1, 2000, 0, 0),
(10, 21, 9, 1, 2000, 0, 0),
(11, 22, 2, 1, 5000, 0, 0),
(12, 22, 4, 1, 8000, 0, 0),
(13, 23, 2, 1, 5000, 0, 0),
(14, 23, 9, 1, 2000, 0, 0),
(15, 24, 2, 1, 5000, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
`id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(80) COLLATE utf8_persian_ci NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_stock` int(11) NOT NULL DEFAULT '0',
  `product_description` text COLLATE utf8_persian_ci,
  `product_picture_name` varchar(180) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `product_brand` int(11) DEFAULT NULL,
  `product_color` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `product_gender` enum('0','1') COLLATE utf8_persian_ci DEFAULT NULL COMMENT '1=>male,0=>female',
  `product_cloth_type` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `product_made_in` int(11) DEFAULT NULL,
  `product_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `product_number_sold` int(11) NOT NULL DEFAULT '0',
  `product_visit_count` int(11) NOT NULL DEFAULT '0',
  `product_is_saleable` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `product_name`, `product_price`, `product_stock`, `product_description`, `product_picture_name`, `product_brand`, `product_color`, `product_gender`, `product_cloth_type`, `product_made_in`, `product_add_date`, `product_number_sold`, `product_visit_count`, `product_is_saleable`) VALUES
(1, 1, 'محصول اول', 1500, 0, 'محصول اول محصول اول محصول اول محصول اول', 'product01.jpg', NULL, 'سبز | زرد', '1', 'نخی | کتان', NULL, '2015-04-01 10:25:26', 5, 0, 1),
(2, 1, 'محصول دوم', 5000, 2, 'محصول دوم محصول دوم محصول دوم محصول دوم محصول دوم', 'product02.jpg', NULL, '', '0', NULL, NULL, '2015-05-02 13:25:26', 8, 0, 1),
(4, 1, 'محصول سوم', 8000, 1, 'محصول سوم محصول سوم محصول سوم محصول سوم', 'product04.jpg', NULL, '', '0', NULL, NULL, '2015-05-03 13:25:26', 2, 0, 1),
(5, 1, 'محصول چهارم', 7800, 8, 'محصول چهارم محصول چهارم محصول چهارم', 'product05.jpg', NULL, '', '0', NULL, NULL, '2015-05-05 13:25:26', 0, 0, 0),
(7, 2, 'عنوان 1', 2000, 4444444, '<p>&nbsp;aaaaaa</p>', 'product01.jpg', 1, 'آبی', '1', 'نخی', 218, '2015-05-26 09:38:53', 0, 0, 0),
(9, 2, 'عنوان 2', 2000, 2, '<strong><span style="color: #ff6600;">sadasdasdasdsad</span></strong>', 'product01.jpg', 2, 'آبی', '0', 'نخی', 205, '2015-05-26 09:49:52', 3, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
`id` int(11) NOT NULL,
  `setting_label` varchar(120) NOT NULL,
  `setting_key` varchar(120) NOT NULL,
  `setting_value` text NOT NULL,
  `setting_type` enum('0','1','2','3','4') NOT NULL COMMENT '0=>boolean,1=>int,2=>float,3=>string,4=>null'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_label`, `setting_key`, `setting_value`, `setting_type`) VALUES
(1, 'مالیات بر ارزش افزوده', 'tax_rate', '9', '3'),
(2, 'نام فروشگاه', 'shop_name', 'تحلیل داده', '3');

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE IF NOT EXISTS `stocks` (
`id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `stock_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stock_type` int(11) NOT NULL,
  `stock_detail` text NOT NULL,
  `stock_count` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`id`, `product_id`, `stock_date`, `stock_type`, `stock_detail`, `stock_count`) VALUES
(1, 2, '2015-05-23 13:19:05', 0, 'کاهش 2 واحد از موجودی. تغییر موجودی از 10 به 8. بابت سفارش شماره: 13', 8),
(2, 1, '2015-05-23 13:28:38', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 5 به 4. بابت سفارش شماره: 14', 4),
(3, 1, '2015-05-24 08:32:21', 0, 'کاهش 2 واحد از موجودی. تغییر موجودی از 4 به 2. بابت سفارش شماره: 15', 2),
(4, 2, '2015-05-24 08:32:21', 0, 'کاهش 2 واحد از موجودی. تغییر موجودی از 8 به 6. بابت سفارش شماره: 15', 6),
(5, 1, '2015-05-26 07:23:37', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 2 به 1. بابت سفارش شماره: 16', 1),
(6, 1, '2015-05-28 04:05:11', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 1 به 0. بابت سفارش شماره: 17', 0),
(7, 2, '2015-05-28 04:09:21', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 6 به 5. بابت سفارش شماره: 18', 5),
(8, 4, '2015-05-28 04:09:51', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 3 به 2. بابت سفارش شماره: 19', 2),
(9, 9, '2015-05-28 04:10:09', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 5 به 4. بابت سفارش شماره: 20', 4),
(10, 9, '2015-05-28 04:28:49', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 4 به 3. بابت سفارش شماره: 21', 3),
(11, 2, '2015-05-28 04:29:23', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 5 به 4. بابت سفارش شماره: 22', 4),
(12, 4, '2015-05-28 04:29:23', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 2 به 1. بابت سفارش شماره: 22', 1),
(13, 2, '2015-05-30 15:54:07', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 4 به 3. بابت سفارش شماره: 23', 3),
(14, 9, '2015-05-30 15:54:07', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 3 به 2. بابت سفارش شماره: 23', 2),
(15, 2, '2015-06-01 04:47:11', 0, 'کاهش 1 واحد از موجودی. تغییر موجودی از 3 به 2. بابت سفارش شماره: 24', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `a_usernmae` (`admin_username`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`id`), ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
 ADD PRIMARY KEY (`id`), ADD KEY `u_id` (`customer_id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
 ADD PRIMARY KEY (`id`), ADD KEY `o_id` (`order_id`,`product_id`), ADD KEY `p_id` (`product_id`), ADD KEY `order_id` (`order_id`), ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`id`), ADD KEY `category_id` (`category_id`), ADD KEY `product_brand` (`product_brand`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `set_key` (`setting_key`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
 ADD PRIMARY KEY (`id`), ADD KEY `p_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=251;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);

--
-- Constraints for table `order_detail`
--
ALTER TABLE `order_detail`
ADD CONSTRAINT `order_detail_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
ADD CONSTRAINT `order_detail_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`product_brand`) REFERENCES `brands` (`id`);

--
-- Constraints for table `stocks`
--
ALTER TABLE `stocks`
ADD CONSTRAINT `stocks_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
